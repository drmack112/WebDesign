makeAccessible();

function makeAccessible()
{
    $("#access-button").click(function(){
        $("#tiny").css("fontSize","12px");
        $("#color-blind").css("color", "black");
    })
}
