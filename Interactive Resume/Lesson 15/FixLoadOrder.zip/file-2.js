function myFunction()
{
    return "Hello";
}

$("body").css("backgroundColor","red");
$("#message2").hide();
