console.log(myFunction() + ", it's nice to meet you!");
$("#message1").hide();