console.log("Adding paragraph text!");

$("#add-text").text("This paragraph now has text!");
