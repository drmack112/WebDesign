//Scripts can be written in different files and then used in our programs as well.
//This cleans up the html file to make it easier to read.
randomRects();

function randomRects()
{
    for(var i = 0; i< 10; i++)
    {
        var div = document.createElement("div");
        var width = parseInt(Math.random() * 350);
        div.setAttribute("style", "width:" + width +"px");
        div.setAttribute("class", "rect");
        $("#container").append(div);
    }
}
